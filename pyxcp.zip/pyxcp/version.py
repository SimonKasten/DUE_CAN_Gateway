# -*- coding: utf-8 -*-
""" pyxcp version module """

__version__ = "0.13.11"
